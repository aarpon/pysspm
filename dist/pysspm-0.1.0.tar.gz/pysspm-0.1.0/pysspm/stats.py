from pysspm.config import ConfigurationParser

# Load configuration (singleton)
CONFIG_PARSER = ConfigurationParser()


class Stats:
    """Class Stats that takes care of collecting project statistics."""

    def __init__(self):
        """Instantiate a Stats object."""
        pass
